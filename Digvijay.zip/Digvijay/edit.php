<?php
error_reporting(0);
//-------------------------Database Connection--------------------------------------------//
$connection = mysql_connect("localhost","root");
mysql_select_db("basic") or die("database could not connect ");
?>

<html>
<head>
<title>Update Student Record</title>
</head>
<body>

<?php
if($_POST["do"]=="update")//Flag for Update
{
	$roll=$_POST["roll"];
	$class=$_POST["class"]; 
	$name=$_POST["name"];
	$fname=$_POST["f_name"];
	$sex=$_POST["sex"];
	$addr1=$_POST["addr1"];
	$addr2=$_POST["addr2"];
	$addr3=$_POST["addr3"];
	$city=$_POST["city"];
	$phone=$_POST["phone"];
	$email=$_POST["email"];
	$remarks=$_POST["remarks"];

   


//--------------------------------------Update Query--------------------------------------//
$query="update student set name='$name',f_name='$fname',sex='$sex',addr1='$addr1',addr2='$addr2',addr3='$addr3',city='$city',phone='$phone',email='$email',remarks='$remarks' where `roll`=$roll";
	$update=mysql_query($query);
	echo "<center>Successfully Updated in DATABASE</center>";
	include("search.php");
}
?>
	<center><h1><u>Student Database</u></h1></center>
	
	<?php
	$roll=$_GET["roll"];

	$query="select * from student where roll='$roll'";
	$result=mysql_query($query);
    while($row = mysql_fetch_assoc($result))
	  { 
		?>
		  <form name="update" method="post" action="edit.php">

		  <input type="hidden" name="do" value="update"> <!-- flag called-->

		  <table style=" border:1px solid silver" cellpadding="5px" cellspacing="0px"align="center" border="0"><tr><td colspan="4" style="background:#0066FF; color:#FFFFFF; font-size:20px">ADD STUDENT RECORD</td></tr><tr><tr><td>Enter Roll Number</td><td>
		  <?php
		  if($_GET[action]=='edit')
			{
			?>
	<input type="hidden" name="save_update" value="save_update"> <!--For Saving Updated values-->
			<?php
			}
		?>
		  <input type="text" name="roll" size="20" readonly value="<?php echo $roll;?>"> </td>
		  <td>Enter Class</td><td>
		  <input type="text" name="class" size="20" value="
		  <?php echo $row['class'];?>"></td></tr>

		  <tr><td>Enter Name of Student</td><td>
		  <input type="text" name="name" size="20" value="<?php echo $row['name'];?>"></td>
		  <td>Enter Father's Name</td><td><input type="text" name="f_name" size="20" value="<?php echo $row['f_name'];?>"></td></tr>
		  <tr><td>Sex</td><td><input type="radio" name="sex" value="Male" checked="checked">Male<input type="radio" name="sex" value="Female">Female </td><td>Address1</td>
		  <td><input type="text" name="addr1" size="20" value="<?php echo $row['addr1'];?>"></td></tr>
		  <tr><td>Address2</td><td><input type="text" name="addr2" size="20" value="<?php echo $row['addr2'];?>"></td>
		  <td>Address3</td><td><input type="text" name="addr3" size="20" value="<?php echo $row['addr3'];?>"></td></tr>
		  <tr><td>City</td><td><input type="text" name="city" size="20" value="<?php echo $row['city'];?>"></td>
		  <td>Phone</td><td><input type="text" name="phone" size="20" value="<?php echo $row['phone'];?>"></td></tr>
		  <tr><td>Email</td><td><input type="text" name="email" size="20" value="<?php echo $row['email'];?>"></td>
		  <td>Remarks</td>
<td><input type="text" name="remarks" size="20" value="<?php echo $row['remarks'];?>"></td></tr>
<tr><td colspan="4" align="center">
<input type="submit" value="UPDATE RECORD"></td></tr></table></form>
	  

<?php } ?><p align="center"><a href="index.php">Go Back to Home</a></p>






</body>
</html>