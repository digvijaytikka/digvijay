<?php
error_reporting(0);
//-------------------------Database Connection--------------------------------------------//
$connection = mysql_connect("localhost","root");
mysql_select_db("basic") or die("database could not connect ");




?>


<html>
<head>
<title>Add Student Record</title>
</head>
<body>
<center><h1><u>Student Database</u></h1></center>

<?php


if($_POST["do"]=="store")  //Flag for value storing
{
//-----------------------------------Variable Declaration-------------------------------------//
	$roll=$_POST["roll"];
	$class=$_POST["class"];
	$name=$_POST["name"];
	$f_name=$_POST["f_name"];
	$sex=$_POST["sex"];
	$addr1=$_POST["addr1"];
	$addr2=$_POST["addr2"];
	$addr3=$_POST["addr3"];
	$city=$_POST["city"];
	$phone=$_POST["phone"];
	$email=$_POST["email"];
	$remarks=$_POST["remarks"];

//---------------------------------------Insert Query-----------------------------------------//
	 $query="insert into student value($roll,'$class','$name','$f_name','$sex','$addr1','$addr2','$addr3','$city','$phone','$email','$remarks')";

	$insert=mysql_query($query);

	echo "<center>Successfully store in DATABASE</center>";
	}
	?>


	<!-------------------------- Html Form----------------------------------->
	<form name="add" method="post" action="add.php">


	<input type="hidden" name="do" value="store"> <!--flag called -->


	<table style=" border:1px solid silver" cellpadding="5px" cellspacing="0px"align="center" border="0">
	<tr>
	<td colspan="4" style="background:#0066FF; color:#FFFFFF; font-size:20px">ADD STUDENT RECORD
	</td>
	</tr>
	<tr>
<tr>
<td>Enter Roll Number</td>
<td><input type="text" name="roll" size="20" maxlength="2" value=""></td>
<td>Enter Class</td>
<td><input type="text" name="class" size="20" maxlength="2" value=""></td>
</tr><tr><td>Enter Name of Student</td>
<td><input type="text" name="name" size="20" value="">
</td>
<td>Enter Father's Name</td>
<td><input type="text" name="f_name" size="20" value="" ></td>
</tr>
<tr><td>Sex</td><td>
<input type="radio" name="sex" value="Male" >Male<input type="radio" name="sex" value="Female">Female </td>
<td>Address1</td>
<td><input type="text" name="addr1" size="20"></td></tr>
<tr><td>Address2</td><td>
<input type="text" name="addr2" size="20" value=""></td>
<td>Address3</td><td>
<input type="text" name="addr3" size="20" value=""></td></tr>
<tr><td>City</td>
<td><input type="text" name="city" size="20" value=""></td>
<td>Phone</td>
<td><input type="text" name="phone" size="20" maxlength="10" value=""></td></tr>
<tr><td>Email</td>
<td><input type="text" name="email" size="20" value=""></td>
<td>Remarks</td>
<td><input type="text" name="remarks" size="20" value=""></td></tr>
<tr><td colspan="4" align="center">

<input type="submit" value="ADD RECORD"></td></tr>






</table>
</form><p align="center"><a href="index.php">Go Back to Home</a></p>

<!-- <?php
include("search.php");
?> -->
</body>
</html>