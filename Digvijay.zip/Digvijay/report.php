<script type="text/javascript" src="css/datetimepicker.js"></script>
<?php
$frm_date   =   $_REQUEST['frm_date'];
$to_date    =   $_REQUEST['to_date'];
$datefrom	=	$_REQUEST[frm_date].' 00:00:00';
$date1		=	$_REQUEST[to_date].' 23:59:59';
$region   	=   $_REQUEST['region'];
$type       =   $_REQUEST['app_type'];
$string     =   'GEN/18-19/'; 
$crs		=	$_REQUEST[crs];

if($region!='')
{
	$add=" and inst_code in (select inst_code from gen_inst_master WHERE region='$region')";
}
else
{
	$add=" and inst_code in (select inst_code from gen_inst_master WHERE region in (1,2,3,4,5))";
}
if($frm_date!='' && $to_date!='')
{
	$add1 = "and STR_TO_DATE(en_on, '%d/%m/%Y %H:%i:%S' ) BETWEEN  
	STR_TO_DATE('$datefrom', '%d-%m-%Y %H:%i:%S' ) AND STR_TO_DATE( '$date1', '%d-%m-%Y %H:%i:%S' )";
}
else
{
	$add1 = "";
}

if($type!='')
{
	$add2=" and type='$type'";
}
else
{
	$add2=" and type in ('A','I')";
}

if($crs!='')
{
	$add3=" and course_code='$crs'";
}
else
{
	$add3=" and course_code in (select course_id from gen_course_master)";
}
?>
<html>
<table id="customers1" width="100%"> 
<form name="self" id="self" action="userindex.php" method="post">
<input type="hidden" name="q" value="region" />
		<tr>
			<td width="35%">
				<div align="right"><b>Application date</b>&nbsp;</div>
			</td>
			<td>	
			 <input type="text" class='tb8' placeholder="From Date" id="frm_date" name="frm_date"  maxlength=15   value="<?php echo $frm_date; ?>">
			 &nbsp;
			<a href="javascript:NewCal('frm_date','ddmmyyyy')"><img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>&nbsp;&nbsp;&nbsp;
			<input type="text" class='tb8' placeholder="To Date" id="to_date" name="to_date"  maxlength=15   value="<?php echo $to_date; ?>">
			 &nbsp;
			<a href="javascript:NewCal('to_date','ddmmyyyy')"><img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>
			</td>
		</tr>
		<tr class="alt">
			<td><div align="right"><b><font color="red">*</font></b> Region</div></td> 
			<td >
			<select id="region" name="region">
				<option value="0">Select Region</option>
				<option value="5">Greater Mumbai</option>
				<option value="1">Mumbai</option>
				<option value="2">Pune</option>
				<option value="3">Aurangabad</option>
				<option value="4">Nagpur</option>
				<option value="">All Regions</option>
			</select>
			</td> 
		</tr>
		<tr class="alt">
			<td><div align="right"><b><font color="red">*</font></b> Application Type</div></td> 
			<td >
			<select id="app_type" name="app_type">
				<option value="0">Select Application Type</option>
				<option value="I">Inspection</option>
				<option value="A">Bed Affiliation</option>
				<option value="">All Types</option>
			</select>
			</td> 
		</tr>
		<tr class="alt">
			<td><div align="right"><b><font color="red">*</font></b> Courses</div></td> 
			<td >
			<select id="crs" name="crs">
				<option value="0">Select Course</option>
				<?php
				$qcourse="select course_id,course_name from gen_course_master";
				$recourse=mysql_query($qcourse);
				while($rowcrs=mysql_fetch_assoc($recourse))
				{
				?>
					<option value="<?php echo $rowcrs[course_id];?>"><?php echo $rowcrs[course_name];?></option>
				<?php
				}
				?>
				<option value="">All Courses</option>
			</select>
			</td> 
		</tr>
	<tr>
	<center><td colspan="2">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input value="Submit" onclick="return validate_fields();" class="button1" type="submit" id="submit" name="Submit" style="width:160px">&nbsp; </td> 
	</center>
		</tr>	
	</table>
<BR>
<div id = "print" align="right">
	<input type="image" src="images/print1.jpg" onClick="document.getElementById('print').style.display = 'none';window.print()"/>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>
</form>
<CENTER>
<?php
if($frm_date!='' && $to_date!='')
{
?>
<table style="align:justify; font-size:10px !important;" id="customers1" width="99%"> 
	<tr>
		<td colspan=15><center><FONT SIZE="3"><B><?php echo HEADER_WORD?></B></FONT><BR> 5th floor, Bombay Mutual Annexe, Gunbow Street, Opp. Residancy Hotel, Off. D. N. Road, Fort, Mumbai, Maharashtra 400001
	 </center></td>
<tr>
	 <td colspan=15>
		<FONT SIZE="">Region:
		<?php
			require_once('get_region_name.php');
			echo get_region_nam($region);
		?>
		</B><br>
        <FONT SIZE="">From Date: <?php echo $frm_date;?>  To Date:<?php echo $to_date;?></B><br>
   </tr>

<tr>
	<th>Sr.No</td>
	<th>Region</td>
	<th>File Number</th>
	<th>Inst.Code</td>
	<th>Institute Name</td>
	<th>Course Name</td>
	<th>Application Type</td>
	<th>Total Amount</td>
	<th>Receipt No</td>
	<th>Date</td>
	
</tr>
<?php
	$i = 1;
	$query  = "SELECT * FROM `paystatus_gen` WHERE `inst_code`!='O' and `course_code`!='O' and  `f_code` in ('ok','OK','Ok') $add $add1 $add2 $add3 order by str_to_date(en_on,'%d/%m/%Y %H:%i:%s')";
	$altcnt ="";
	$result = mysql_query($query) or die ("Unable :".$query);
	while($row    = mysql_fetch_array($result))
	{
	$crs = "SELECT inst_name, region FROM gen_inst_master WHERE inst_code = '$row[inst_code]'";
	$csrp = mysql_query($crs) or die ("Error while Fetching record".mysql_error());
	$crsr    = mysql_fetch_array($csrp);
	$name = stripslashes(stripslashes(stripslashes($crsr[inst_name])));

	$ccrs = "SELECT course_name FROM gen_course_master WHERE course_id = '$row[course_code]'";
	$ccsrp = mysql_query($ccrs) or die ("Error while Fetching record".mysql_error());
	$ccrsr    = mysql_fetch_array($ccsrp);
	$course_name = stripslashes(stripslashes(stripslashes($ccrsr[course_name])));
	
	$quu="select file_no, ins_type from gen_inst_course_details where inst_code=trim('$row[inst_code]') and course_code=TRIM(LEADING '0' from $row[course_code])";
			$ree=mysql_query($quu);
			$rrr=mysql_fetch_assoc($ree);

	if ($row[type]=="A")
	{
		$app_type	=	"Bed Affiliation";
	}
	else if ($row[type]=="I")
	{
		$app_type	= $rrr[ins_type];
	}


?>
<tr>
	<td><?php echo $i;?></td>
	<td><?php echo get_region_nam($crsr[region]);?></td>
	<td>
		<?php 
			echo $rrr[file_no];
		?>
	</td>
	<td><?php echo (int)($row[inst_code]);?></td>
	<td><?php echo $name;?></td>
	<td><?php echo (int)($row[course_code]);?> - <?php echo $course_name;?></td>
	<td>
	<?php 
	echo $app_type;
		if($row[amt]!='5000' and $row[amt]!='10000' and $row[amt]!='25000')
		{
			echo ' With Late Fees';
		}
	?></td>
	<td><?php echo $row[amt];?></td>
	<td><?php echo $string.$row[id];?></td>
	<td><?php echo $row[en_on];?></td>
	
</tr>
<?php
	$i++;
	}
?>
</table>
<?php
}
?>
</html>
