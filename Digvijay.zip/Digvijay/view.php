<?php
mysql_connect("localhost");
mysql_select_db("test") or die("database could not connect");
?>
<html>
<head>
<title>View StudentRecord</title>
</head>
<body>
<center>
<h1>
<u>Student Database</u>
</h1>
</center>
<?
$roll=$_GET["roll"];
$query="select * from student where roll='$roll'";
$result=mysql_query($query);
while ($row = mysql_fetch_array($result)) 
{ 
	?>
	<table style=" border:1px solid silver" cellpadding="5px" cellspacing="0px"align="center" border="1"><tr><td colspan="4" style="background:#0066FF; color:#FFFFFF; font-size:20px">VIEWSTUDENT DATABASE</td></tr>
	<tr><td> Roll Number</td><td><? echo $row['roll'];?></td>
	<td> Class</td><td><? echo $row[1];?></td></tr>
	<tr><td> Name of Student</td><td><? echo $row[2];?></td>
	<td> Father's Name</td><td><? echo $row[3];?></td></tr>
	<tr><td>Sex</td><td><? echo $row[4];?></td>
	<td>Address1</td><td><? echo $row[5];?></td></tr>
	<tr><td>Address2</td><td><? echo $row[6];?></td>
	<td>Address3</td><td><? echo $row[7];?></td></tr>
	<tr><td>City</td><td><? echo $row[8];?></td>
	<td>Phone</td><td><? echo $row[9];?></td></tr>
	<tr><td>Email</td><td><? echo $row[10];?></td>
	<td>Remarks</td><td><? echo $row[11];?></td></tr>
	<tr></table><?}?><p align="center">
	<a href="index.php">Go Back to Home</a></p>
	</body></html>