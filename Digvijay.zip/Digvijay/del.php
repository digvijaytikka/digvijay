<?php
error_reporting(0);
//-------------------------Database Connection--------------------------------------------//
$connection = mysql_connect("localhost","root");
mysql_select_db("basic") or die("database could not connect ");
?>
<html>
<head>
<title>Add Student Record</title>
</head><body>
<?php
$roll=$_GET["roll"];


$query="delete from student where roll=$roll";
$delete=mysql_query($query);
echo "<center>Successfully Deleted</center>";
include("search.php");
?>
</body>
</html>
